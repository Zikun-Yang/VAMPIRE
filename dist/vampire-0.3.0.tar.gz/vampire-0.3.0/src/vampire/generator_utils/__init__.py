# generator_utils/__init__.py
from .singleMotifTR import TR_singleMotif
from .multiMotifTR import TR_multiMotif

__all__ = ['TR_singleMotif', 'TR_multiMotif']