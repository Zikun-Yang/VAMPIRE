# VAMPIRE - A tool for annotating the motif variation and complex patterns in tandem repeats.

https://zikun-yang.github.io/VAMPIRE_Cookbook/

## Introduction

## Installation

## Usage

## Citation

## Contact
